package com.word.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    private MoviesAdapter mAdapter;


    private List<E_Codemodel> movieList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mAdapter = new MoviesAdapter(MainActivity.this,movieList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        AddData();

    }

    private void AddData /m,        90kkmmmmm, ,,,,,,,,,,,,,,,,() {
        E_Codemodel e_codemodel = new E_Codemodel("Device ID", 010);
        movieList.add(e_codemodel);

         e_codemodel = new E_Codemodel("Device ID", 015);
        movieList.add(e_codemodel);

         e_codemodel = new E_Codemodel("Device ID23", 012);
        movieList.add(e_codemodel);

         e_codemodel = new E_Codemodel("Device ID33", 013);
        movieList.add(e_codemodel);

         e_codemodel = new E_Codemodel("Device ID24", 014);
        movieList.add(e_codemodel);

         e_codemodel = new E_Codemodel("Device ID243", 015);
        movieList.add(e_codemodel);



        mAdapter.notifyDataSetChanged();
    }


}
