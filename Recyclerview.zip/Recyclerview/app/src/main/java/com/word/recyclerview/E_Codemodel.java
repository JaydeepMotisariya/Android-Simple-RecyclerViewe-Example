package com.word.recyclerview;

public class E_Codemodel {
    private String  message;

    int code;
 
    public E_Codemodel() {
    }


    public E_Codemodel(String message, int code) {
        this.message = message;
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}